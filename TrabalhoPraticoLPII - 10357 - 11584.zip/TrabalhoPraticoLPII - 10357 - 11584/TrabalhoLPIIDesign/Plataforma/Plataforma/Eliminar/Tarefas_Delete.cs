﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace Plataforma.Eliminar
{
    public partial class Tarefas_Delete : Form
    {
        public Tarefas_Delete()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Tarefas
            Tarefas tarefas = new Tarefas();
            tarefas.Show();


            //Esconder Página Tarefas_Delete
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            domainUpDown1.Enabled = false;

            dataGridView1.Rows.Clear();

            foreach (var aux in Ficheiro.tarefas)
            {
                if (aux.IdTarefa == int.Parse(domainUpDown1.Text))
                {
                    dataGridView1.ColumnCount = 7;
                    dataGridView1.Columns[0].Name = "ID Tarefa";
                    dataGridView1.Columns[1].Name = "ID Projeto";
                    dataGridView1.Columns[2].Name = "ID Utilizador";
                    dataGridView1.Columns[3].Name = "Agenda";
                    dataGridView1.Columns[4].Name = "Titulo";
                    dataGridView1.Columns[5].Name = "Descrição";
                    dataGridView1.Columns[6].Name = "Estado";

                    string[] row = new string[] { aux.IdTarefa.ToString(), aux.IdProjeto.ToString(), aux.IdUtilizador.ToString(), aux.Agenda, aux.Titulo, aux.Descricao, aux.Estado };

                    dataGridView1.Rows.Add(row);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Declaração de variável para eliminação de Tarefas
            ClassTarefas tarefa = new ClassTarefas();


            if (domainUpDown1.Text != "")
            {
                //Receber valores para as variáveis
                tarefa.IdTarefa = int.Parse(domainUpDown1.Text);


                //Chamada da função de edição na lista
                Ficheiro.EliminarTarefas(tarefa);

                //Mensagem de Sucesso
                MessageBox.Show("Tarefa Eliminada com Sucesso!");

            }
            else
            {
                MessageBox.Show("Não existem dados para eliminar!");
            }
        }

        private void Tarefas_Delete_Load(object sender, EventArgs e)
        {
            //Condição que verifica se existem valores inseridos
            if (Ficheiro.tarefas.Count > 0)
            {
                foreach (var tarefa in Ficheiro.tarefas)
                {
                    domainUpDown1.Items.Add(tarefa.IdTarefa);
                }

            }
        }
    }
}
