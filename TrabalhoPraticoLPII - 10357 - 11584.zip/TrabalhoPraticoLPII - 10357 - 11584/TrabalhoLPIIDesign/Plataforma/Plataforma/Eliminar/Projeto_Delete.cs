﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace Plataforma.Eliminar
{
    public partial class Projeto_Delete : Form
    {
        public Projeto_Delete()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Projeto
            Projeto projeto = new Projeto();
            projeto.Show();


            //Esconder Página Projeto_Delete
            Close();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            domainUpDown1.Enabled = false;

            dataGridView1.Rows.Clear();

            foreach (var aux in Ficheiro.projetos)
            {
                if (aux.IdProjeto == int.Parse(domainUpDown1.Text))
                {
                    dataGridView1.ColumnCount = 3;
                    dataGridView1.Columns[0].Name = "ID Projeto";
                    dataGridView1.Columns[1].Name = "Nome";
                    dataGridView1.Columns[2].Name = "Data Início";

                    string[] row = new string[] { aux.IdProjeto.ToString(), aux.Nome, aux.DataInicio };

                    dataGridView1.Rows.Add(row);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Declaração de variável para eliminação de Projetos
            ClassProjetos projeto = new ClassProjetos();

            if (domainUpDown1.Text != "")
            {
                //Receber valores para as variáveis
                projeto.IdProjeto = int.Parse(domainUpDown1.Text);


                //Chamada da função de edição na lista
                Ficheiro.EliminarProjetos(projeto);

                //Mensagem de Sucesso
                MessageBox.Show("Projeto Eliminado com Sucesso!");
            }
            else
            {
                MessageBox.Show("Não existem dados para eliminar!");
            }
            

        }
    }
}
