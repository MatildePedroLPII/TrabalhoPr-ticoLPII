﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace Plataforma.Eliminar
{
    public partial class Bugs_Delete : Form
    {
        public Bugs_Delete()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Bugs
            Bugs bugs = new Bugs();
            bugs.Show();


            //Esconder Página Bugs_Delete
            Close();
        }

        private void Bugs_Delete_Load(object sender, EventArgs e)
        {
            //Condição que verifica se existem valores inseridos
            if (Ficheiro.bugs.Count > 0)
            {
                foreach (var bug in Ficheiro.bugs)
                {
                    domainUpDown1.Items.Add(bug.IdBug);
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            domainUpDown1.Enabled = false;

            dataGridView1.Rows.Clear();

            foreach (var aux in Ficheiro.bugs)
            {
                if (aux.IdBug == int.Parse(domainUpDown1.Text))
                {
                    dataGridView1.ColumnCount = 5;
                    dataGridView1.Columns[0].Name = "ID Bug";
                    dataGridView1.Columns[1].Name = "ID Projeto";
                    dataGridView1.Columns[2].Name = "Titulo";
                    dataGridView1.Columns[3].Name = "Descrição";
                    dataGridView1.Columns[4].Name = "Estado";

                    string[] row = new string[] { aux.IdBug.ToString(), aux.IdProjeto.ToString(), aux.Titulo, aux.Descricao, aux.Estado };

                    dataGridView1.Rows.Add(row);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Declaração de variável para eliminação de Sprints
            ClassBugs bug = new ClassBugs();


            if (domainUpDown1.Text != "")
            {
                //Receber valores para as variáveis
                bug.IdBug = int.Parse(domainUpDown1.Text);


                //Chamada da função de edição na lista
                Ficheiro.EliminarBugs(bug);

                //Mensagem de Sucesso
                MessageBox.Show("Bug Eliminado com Sucesso!");

            }
            else
            {
                MessageBox.Show("Não existem dados para eliminar!");
            }
        }
    }
}
