﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Plataforma.Adicionar;
using Plataforma.Editar;
using Plataforma.Eliminar;
using Biblioteca;

namespace Plataforma
{
    public partial class Projeto : Form
    {
        public Projeto()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Plataforma
            Plataforma plataforma = new Plataforma();
            plataforma.Show();


            //Esconder Página Utilizadores
            Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Abre a Página de Inserção de Projeto
            Projeto_Add projetoAdd = new Projeto_Add();
            projetoAdd.Show();

            //Esconder Página Projeto
            Close();
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            //Abre a Página de Edição de Projeto
            Projeto_Edit projetoEdit = new Projeto_Edit();
            projetoEdit.Show();

            //Esconder Página Projeto
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Abre a Página de Eliminação de Projeto
            Projeto_Delete projetoDelete = new Projeto_Delete();
            projetoDelete.Show();

            //Esconder Página Projeto
            Close();
        }

        private void Projeto_Load(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();

            dataGridView1.ColumnCount = 3;
            dataGridView1.Columns[0].Name = "ID Projeto";
            dataGridView1.Columns[1].Name = "Nome";
            dataGridView1.Columns[2].Name = "Data Início";

            foreach (var aux in Ficheiro.projetos)
            {
                string[] row = new string[] { aux.IdProjeto.ToString(), aux.Nome, aux.DataInicio };

                dataGridView1.Rows.Add(row);
                
            }
        }
    }
}
