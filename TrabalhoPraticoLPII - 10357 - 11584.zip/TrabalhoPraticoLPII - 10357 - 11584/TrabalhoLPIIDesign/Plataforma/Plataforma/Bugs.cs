﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Plataforma.Adicionar;
using Plataforma.Editar;
using Plataforma.Eliminar;
using Biblioteca;

namespace Plataforma
{
    public partial class Bugs : Form
    {
        public Bugs()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Plataforma
            Plataforma plataforma = new Plataforma();
            plataforma.Show();


            //Esconder Página Utilizadores
            Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Abre a Página de Inserção de Bugs
            Bugs_Add bugAdd = new Bugs_Add();
            bugAdd.Show();

            //Esconder Página Bugs
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Abre a Página de Edição de Bugs
            Bugs_Edit bugEdit = new Bugs_Edit();
            bugEdit.Show();

            //Esconder Página Bugs
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Abre a Página de Eliminação de Bugs
            Bugs_Delete bugDelete = new Bugs_Delete();
            bugDelete.Show();

            //Esconder Página Bugs
            Close();
        }

        private void Bugs_Load(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();

            dataGridView1.ColumnCount = 5;
            dataGridView1.Columns[0].Name = "ID Bug";
            dataGridView1.Columns[1].Name = "ID Projeto";
            dataGridView1.Columns[2].Name = "Titulo";
            dataGridView1.Columns[3].Name = "Descrição";
            dataGridView1.Columns[4].Name = "Estado";

            foreach (var aux in Ficheiro.bugs)
            {
                string[] row = new string[] { aux.IdBug.ToString(), aux.IdProjeto.ToString(), aux.Titulo, aux.Descricao, aux.Estado };

                dataGridView1.Rows.Add(row);

             
            }
        }
    }
}
