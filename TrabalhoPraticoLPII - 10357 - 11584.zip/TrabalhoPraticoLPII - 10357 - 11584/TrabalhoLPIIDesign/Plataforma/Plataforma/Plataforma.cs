﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;
using System.IO;

namespace Plataforma
{
    public partial class Plataforma : Form
    {
       
        public Plataforma()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Abrir Página Utilizadores
            Utilizadores utilizadores = new Utilizadores();
            utilizadores.Show();

           
            //Esconder Página Plataforma
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Abrir Página Projetos
            Projeto projeto = new Projeto();
            projeto.Show();


            //Esconder Página Plataforma
            Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Abrir Página Tarefas
            Tarefas tarefas = new Tarefas();
            tarefas.Show();


            //Esconder Página Plataforma
            Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Sprints
            Sprints sprints = new Sprints();
            sprints.Show();


            //Esconder Página Plataforma
            Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Abrir Página Bugs
            Bugs bugs = new Bugs();
            bugs.Show();


            //Esconder Página Plataforma
            Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void Plataforma_Load(object sender, EventArgs e)
        {
            if (!File.Exists(AppDomain.CurrentDomain.BaseDirectory + "utilizadores.txt"))
            {
                File.Create("utilizadores.txt").Dispose();
            }

            if (!File.Exists(AppDomain.CurrentDomain.BaseDirectory + "projetos.txt"))
            {
                File.Create("projetos.txt").Dispose();
            }

            if (!File.Exists(AppDomain.CurrentDomain.BaseDirectory + "tarefas.txt"))
            {
                File.Create("tarefas.txt").Dispose();
            }

            if (!File.Exists(AppDomain.CurrentDomain.BaseDirectory + "sprints.txt"))
            {
                File.Create("sprints.txt").Dispose();
            }

            if (!File.Exists(AppDomain.CurrentDomain.BaseDirectory + "bugs.txt"))
            {
                File.Create("bugs.txt").Dispose();
            }

            //Faz a leitura dos dados do ficheiro
            Ficheiro.LeituraDados();

            
        }
    }
}
