﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Plataforma.Adicionar;
using Plataforma.Editar;
using Plataforma.Eliminar;
using Biblioteca;

namespace Plataforma
{
    public partial class Utilizadores : Form
    {
        public Utilizadores()
        {
            InitializeComponent();
        }


        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Plataforma
            Plataforma plataforma = new Plataforma();
            plataforma.Show();


            //Esconder Página Utilizadores
            Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Abre a Página de Inserção de Utilizador
            Utilizador_Add utilizadorAdd = new Utilizador_Add();
            utilizadorAdd.Show();

            //Esconder Página Utilizador
            Close();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            //Abre a Página de Edição de Utilizador
            Utilizadores_Edit utilizadorEdit = new Utilizadores_Edit();
            utilizadorEdit.Show();

            //Esconder Página Utilizador
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Abre a Página de Eliminação de Utilizador
            Utilizadores_Delete utilizadorDelete = new Utilizadores_Delete();
            utilizadorDelete.Show();

            //Esconder Página Utilizador
            Close();
        }

        private void Utilizadores_Load(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();

            dataGridView1.ColumnCount = 3;
            dataGridView1.Columns[0].Name = "ID Utilizador";
            dataGridView1.Columns[1].Name = "Nome";
            dataGridView1.Columns[2].Name = "Email";

            foreach (var aux in Ficheiro.utilizadores)
            {
                
                string[] row = new string[] { aux.IdUtilizador.ToString(), aux.Nome, aux.Email };

                dataGridView1.Rows.Add(row);
                
            }
        }
    }
}
