﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Plataforma.Adicionar;
using Plataforma.Editar;
using Plataforma.Eliminar;
using Biblioteca;

namespace Plataforma
{
    public partial class Sprints : Form
    {
        public Sprints()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Plataforma
            Plataforma plataforma = new Plataforma();
            plataforma.Show();


            //Esconder Página Utilizadores
            Close();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            //Abre a Página de Inserção de Sprints
            Sprints_Add sprintsAdd = new Sprints_Add();
            sprintsAdd.Show();

            //Esconder Página Sprints
            Close();
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            //Abre a Página de Edição de Sprints
            Sprints_Edit sprintsEdit = new Sprints_Edit();
            sprintsEdit.Show();

            //Esconder Página Sprints
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Abre a Página de Eliminação de Sprints
            Sprints_Delete sprintsDelete = new Sprints_Delete();
            sprintsDelete.Show();

            //Esconder Página Sprints
            Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void Sprints_Load(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();

            dataGridView1.ColumnCount = 5;
            dataGridView1.Columns[0].Name = "ID Sprint";
            dataGridView1.Columns[1].Name = "ID Projeto";
            dataGridView1.Columns[2].Name = "Agenda";
            dataGridView1.Columns[3].Name = "Descrição";
            dataGridView1.Columns[4].Name = "Estado";

            foreach (var aux in Ficheiro.sprints)
            {
                string[] row = new string[] { aux.IdSprint.ToString(), aux.IdProjeto.ToString(), aux.Agenda, aux.Descricao, aux.Estado };

                dataGridView1.Rows.Add(row);
                
            }
        }
    }
}
