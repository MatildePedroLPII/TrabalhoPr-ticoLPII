﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace Plataforma.Editar
{
    public partial class Bugs_Edit : Form
    {
        public Bugs_Edit()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Bugs
            Bugs bugs = new Bugs();
            bugs.Show();


            //Esconder Página Bugs_Edit
            Close();
        }

        private void Bugs_Edit_Load(object sender, EventArgs e)
        {
            //Condição que verifica se existem valores inseridos
            if (Ficheiro.bugs.Count > 0)
            {
                foreach (var bug in Ficheiro.bugs)
                {
                    domainUpDown1.Items.Add(bug.IdBug);
                }

                //Desabilitar formulário ao carregar página
                domainUpDown2.Enabled = false;
                label2.Enabled = false;
                textBox3.Enabled = false;
                label4.Enabled = false;
                textBox5.Enabled = false;
                label3.Enabled = false;
                textBox4.Enabled = false;
                button1.Enabled = false;

            }
            else
            {
                MessageBox.Show("Não existem dados para Editar!");

                //Desabilitar todos os formulário ao carregar página
                label1.Enabled = false;
                domainUpDown2.Enabled = false;
                label2.Enabled = false;
                textBox3.Enabled = false;
                label4.Enabled = false;
                textBox5.Enabled = false;
                label3.Enabled = false;
                textBox4.Enabled = false;
                button1.Enabled = false;
                button2.Enabled = false;
                domainUpDown1.Enabled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Enabled = true;
            domainUpDown2.Enabled = false;
            label2.Enabled = true;
            textBox3.Enabled = true;
            label4.Enabled = true;
            textBox5.Enabled = true;
            label3.Enabled = true;
            textBox4.Enabled = true;
            button1.Enabled = true;
            button2.Enabled = false;

            //Preencher ID de Projeto possíveis para escolha
            foreach (var projeto in Ficheiro.projetos)
            {
                domainUpDown2.Items.Add(projeto.IdProjeto);
            }

            foreach (var aux in Ficheiro.bugs)
            {
                if (aux.IdBug == int.Parse(domainUpDown1.Text))
                {
                    domainUpDown2.Text = aux.IdProjeto.ToString();
                    textBox3.Text = aux.Titulo;
                    textBox4.Text = aux.Descricao;
                    textBox5.Text = aux.Estado;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Declaração de variável para edição de Bugs
            ClassBugs bug = new ClassBugs();

            //Receber valores para as variáveis
            bug.IdBug = int.Parse(domainUpDown1.Text);
            bug.IdProjeto = int.Parse(domainUpDown2.Text);
            bug.Titulo = textBox3.Text;
            bug.Descricao = textBox4.Text;
            bug.Estado = textBox5.Text;


            //Chamada da função de edição na lista
            Ficheiro.EditarBugs(bug);

            //Mensagem de Sucesso
            MessageBox.Show("Bug Editado com Sucesso!");
        }
    }
 }

