﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace Plataforma.Editar
{
    public partial class Tarefas_Edit : Form
    {
        public Tarefas_Edit()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Tarefas
            Tarefas tarefas = new Tarefas();
            tarefas.Show();


            //Esconder Página Tarefas_Edit
            Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void Tarefas_Edit_Load(object sender, EventArgs e)
        {
            //Condição que verifica se existem valores inseridos
            if (Ficheiro.tarefas.Count > 0)
            {
                foreach (var tarefa in Ficheiro.tarefas)
                {
                    domainUpDown1.Items.Add(tarefa.IdTarefa);
                }
                //Desabilitar formulário ao carregar página
                label6.Enabled = false;
                label4.Enabled = false;
                label1.Enabled = false;
                textBox2.Enabled = false;
                label2.Enabled = false;
                textBox3.Enabled = false;
                label8.Enabled = false;
                textBox7.Enabled = false;
                label7.Enabled = false;
                textBox6.Enabled = false;
                button1.Enabled = false;
                domainUpDown2.Enabled = false;
                domainUpDown3.Enabled = false;
            }
            else
            {
                MessageBox.Show("Não existem dados para Editar!");

                //Desabilitar formulário ao carregar página
                label6.Enabled = false;
                label4.Enabled = false;
                label1.Enabled = false;
                textBox2.Enabled = false;
                label2.Enabled = false;
                textBox3.Enabled = false;
                label8.Enabled = false;
                textBox7.Enabled = false;
                label7.Enabled = false;
                textBox6.Enabled = false;
                button1.Enabled = false;
                domainUpDown1.Enabled = false;
                domainUpDown2.Enabled = false;
                domainUpDown3.Enabled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            domainUpDown2.Enabled = false;
            domainUpDown3.Enabled = false;
            label6.Enabled = true;
            label4.Enabled = true;
            label1.Enabled = true;
            textBox2.Enabled = true;
            label2.Enabled = true;
            textBox3.Enabled = true;
            label8.Enabled = true;
            textBox7.Enabled = true;
            label7.Enabled = true;
            textBox6.Enabled = true;
            button1.Enabled = true;
            button2.Enabled = false;
            
            //Preencher ID de Projeto possíveis para escolha
            foreach (var projeto in Ficheiro.projetos)
            {
                domainUpDown2.Items.Add(projeto.IdProjeto);
            }

            //Preencher ID de Utilizador possíveis para escolha
            foreach (var utilizador in Ficheiro.utilizadores)
            {
                domainUpDown2.Items.Add(utilizador.IdUtilizador);
            }

            foreach (var aux in Ficheiro.tarefas)
            {
                if (aux.IdTarefa == int.Parse(domainUpDown1.Text))
                {
                    domainUpDown2.Text = aux.IdProjeto.ToString();
                    domainUpDown3.Text = aux.IdUtilizador.ToString();
                    textBox2.Text = aux.Agenda;
                    textBox3.Text = aux.Titulo;
                    textBox7.Text = aux.Descricao;
                    textBox6.Text = aux.Estado;
                }
            }
        }
    }
}
