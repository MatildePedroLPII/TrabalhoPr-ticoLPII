﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace Plataforma.Editar
{
    public partial class Utilizadores_Edit : Form
    {
        public Utilizadores_Edit()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Utilizador
            Utilizadores utilizador = new Utilizadores();
            utilizador.Show();


            //Esconder Página Utilizador_Edit
            Close();
        }

        private void Utilizadores_Edit_Load(object sender, EventArgs e)
        {
            //Condição que verifica se existem valores inseridos
            if (Ficheiro.utilizadores.Count > 0)
            {
                foreach (var utilizador in Ficheiro.utilizadores)
                {
                    domainUpDown1.Items.Add(utilizador.IdUtilizador);
                }

                //Desabilitar formulário ao carregar página
                label1.Enabled = false;
                textBox2.Enabled = false;
                label2.Enabled = false;
                textBox3.Enabled = false;
                button1.Enabled = false;

            }
            else
            {
                MessageBox.Show("Não existem dados para Editar!");

                //Desabilitar todos os formulário ao carregar página
                label1.Enabled = false;
                textBox2.Enabled = false;
                label2.Enabled = false;
                textBox3.Enabled = false;
                button1.Enabled = false;
                button2.Enabled = false;
                domainUpDown1.Enabled = false;
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Condição que verifica se o ID inserido é válido (Se já existe)
            label1.Enabled = true;
            textBox2.Enabled = true;
            label2.Enabled = true;
            textBox3.Enabled = true;
            button1.Enabled = true;
            domainUpDown1.Enabled = false;
            button2.Enabled = false;


            foreach (var aux in Ficheiro.utilizadores)
            {
                if (aux.IdUtilizador == int.Parse(domainUpDown1.Text))
                {
                    textBox2.Text = aux.Nome;
                    textBox3.Text = aux.Email;
                }
            }



        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Declaração de variável para edição de Utilizadores
            ClassUtilizadores utilizador = new ClassUtilizadores();

            //Receber valores para as variáveis
            utilizador.IdUtilizador = int.Parse(domainUpDown1.Text);
            utilizador.Nome = textBox2.Text;
            utilizador.Email = textBox3.Text;
            

            //Chamada da função de edição na lista
            Ficheiro.EditarUtilizadores(utilizador);

            //Mensagem de Sucesso
            MessageBox.Show("Utilizador Editado com Sucesso!");
            
        }
    }
}
