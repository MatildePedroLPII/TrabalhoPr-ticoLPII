﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace Plataforma.Adicionar
{
    public partial class Utilizador_Add : Form
    {
        public Utilizador_Add()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Utilizador
            Utilizadores utilizador = new Utilizadores();
            utilizador.Show();


            //Esconder Página Utilizador_Add
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Declaração de variável para inserção de Utilizadores
            ClassUtilizadores utilizador = new ClassUtilizadores();

            //Receber valores para as variáveis
            int aux;
            bool result = int.TryParse(textBox1.Text, out aux);
            utilizador.Nome = textBox2.Text;
            utilizador.Email = textBox3.Text;

            //Validação dos ID's
            if (result == true)
            {
                utilizador.IdUtilizador = aux;

                //Chamada da função de inserção na lista
                Ficheiro.InserirUtilizadores(utilizador);

                //Mensagem de Sucesso
                MessageBox.Show("Utilizador Inserido com Sucesso!");
            }
            else
            {
                MessageBox.Show("Inseriu uma valor inválido num dos campos de ID do formulário!");
            }
        }

        private void Utilizador_Add_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;

            if (Ficheiro.utilizadores.Count > 0)
            {
                textBox1.Text = (Ficheiro.utilizadores[Ficheiro.utilizadores.Count - 1].IdUtilizador + 1).ToString();

            }
            else
            {
                textBox1.Text = "1";
            }

        }
    }
}
