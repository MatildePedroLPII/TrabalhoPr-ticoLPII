﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace Plataforma.Adicionar
{
    public partial class Projeto_Add : Form
    {
        public Projeto_Add()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Projeto
            Projeto projeto = new Projeto();
            projeto.Show();


            //Esconder Página Projeto_Add
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Declaração de variável para inserção de Projetos
            ClassProjetos projetos = new ClassProjetos();

            //Receber valores para as variáveis
            int aux;
            bool result = int.TryParse(textBox1.Text, out aux);
            projetos.Nome = textBox2.Text;
            projetos.DataInicio = textBox3.Text;

            //Validação dos ID's
            if (result == true )
            {
                projetos.IdProjeto = aux;

                //Chamada da função de inserção na lista
                Ficheiro.InserirProjetos(projetos);

                //Mensagem de Sucesso
                MessageBox.Show("Projeto Inserido com Sucesso!");

            }
            else
            {
                MessageBox.Show("Inseriu uma valor inválido num dos campos de ID do formulário!");
            }

        }

        private void Projeto_Add_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;

            if (Ficheiro.projetos.Count > 0)
            {
                textBox1.Text = (Ficheiro.projetos[Ficheiro.projetos.Count - 1].IdProjeto + 1).ToString();

            }
            else
            {
                textBox1.Text = "1";
            }
        }
    }
}
