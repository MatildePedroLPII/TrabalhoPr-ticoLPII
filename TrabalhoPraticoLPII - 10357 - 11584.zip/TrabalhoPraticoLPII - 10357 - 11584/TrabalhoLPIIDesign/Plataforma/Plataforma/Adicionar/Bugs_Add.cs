﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace Plataforma.Adicionar
{
    public partial class Bugs_Add : Form
    {
        public Bugs_Add()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Bugs
            Bugs bugs = new Bugs();
            bugs.Show();


            //Esconder Página Bugs_Add
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Declaração de variável para inserção de Bugs
            ClassBugs bugs = new ClassBugs();

            //Receber valores para as variáveis
            int aux, aux2;
            bool result = int.TryParse(textBox1.Text, out aux);
            bool result2 = int.TryParse(domainUpDown1.Text, out aux2);
            bugs.Titulo = textBox3.Text;
            bugs.Descricao = textBox4.Text;
            bugs.Estado = textBox5.Text;

            //Validação dos ID's
            if (result == true && result2 == true)
            {
                bugs.IdBug = aux;
                bugs.IdProjeto = aux2;

                //Chamada da função de inserção na lista
                Ficheiro.InserirBugs(bugs);

                //Mensagem de Sucesso
                MessageBox.Show("Bug Inserido com Sucesso!");

            }
            else
            {
                MessageBox.Show("Inseriu uma valor inválido num dos campos de ID do formulário!");
            }
            

            
        }

        private void Bugs_Add_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;

            //Condição que verifica se existem valores inseridos
            if (Ficheiro.projetos.Count > 0)
            {
                foreach (var projeto in Ficheiro.projetos)
                {
                    domainUpDown1.Items.Add(projeto.IdProjeto);
                }

                if (Ficheiro.bugs.Count > 0)
                {
                    textBox1.Text = (Ficheiro.bugs[Ficheiro.bugs.Count - 1].IdBug + 1).ToString();

                }
                else
                {
                    textBox1.Text = "1";
                }

            }
            else
            {
                MessageBox.Show("Não é possível inserir Bugs sem haver Projetos inseridos");
                textBox3.Enabled = false;
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                domainUpDown1.Enabled = false;
                button1.Enabled = false;
                label1.Enabled = false;
                label2.Enabled = false;
                label3.Enabled = false;
                label4.Enabled = false;
                label6.Enabled = false;
            }
        }
    }
}
