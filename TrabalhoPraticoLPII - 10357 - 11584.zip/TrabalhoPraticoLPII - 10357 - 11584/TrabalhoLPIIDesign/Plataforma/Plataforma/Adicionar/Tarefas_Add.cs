﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;

namespace Plataforma.Adicionar
{
    public partial class Tarefas_Add : Form
    {
        public Tarefas_Add()
        {
            InitializeComponent();
        }


        private void button6_Click(object sender, EventArgs e)
        {

            //Guardar informações dos utilizadores na base de dados
            Ficheiro.GuardarFicheiroUtilizadores();

            //Guardar informações dos projetos na base de dados
            Ficheiro.GuardarFicheiroProjetos();

            //Guardar informações das tarefas na base de dados
            Ficheiro.GuardarFicheiroTarefas();

            //Guardar informações dos sprints na base de dados
            Ficheiro.GuardarFicheiroSprints();

            //Guardar informações dos bugs na base de dados
            Ficheiro.GuardarFicheiroBugs();

            //Fecha a Aplicação
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Abrir Página Tarefas
            Tarefas tarefas = new Tarefas();
            tarefas.Show();


            //Esconder Página Tarefas_Add
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Declaração de variável para inserção de Tarefas
            ClassTarefas tarefas = new ClassTarefas();

            //Receber valores para as variáveis
            int aux, aux2, aux3;
            bool result = int.TryParse(textBox1.Text, out aux);
            bool result2 = int.TryParse(domainUpDown1.Text, out aux2);
            bool result3 = int.TryParse(domainUpDown2.Text, out aux3);
            tarefas.Agenda = textBox4.Text;
            tarefas.Titulo = textBox5.Text;
            tarefas.Descricao = textBox6.Text;
            tarefas.Estado = textBox7.Text;

            //Validação dos ID's
            if (result == true && result2 == true && result3 == true)
            {
                tarefas.IdTarefa = aux;
                tarefas.IdProjeto = aux2;
                tarefas.IdUtilizador = aux3;

                //Chamada da função de inserção na lista
                Ficheiro.InserirTarefas(tarefas);

                //Mensagem de Sucesso
                MessageBox.Show("Tarefa Inserida com Sucesso!");
            }
            else
            {
                MessageBox.Show("Inseriu uma valor inválido num dos campos de ID do formulário!");
            }

        }

        private void Tarefas_Add_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;

            //Condição que verifica se existem valores inseridos
            if (Ficheiro.projetos.Count > 0 && Ficheiro.utilizadores.Count > 0)
            {
                foreach (var projeto in Ficheiro.projetos)
                {
                    domainUpDown1.Items.Add(projeto.IdProjeto);
                }

                foreach (var utilizador in Ficheiro.utilizadores)
                {
                    domainUpDown2.Items.Add(utilizador.IdUtilizador);
                }

                if (Ficheiro.tarefas.Count > 0)
                {
                    textBox1.Text = (Ficheiro.tarefas[Ficheiro.tarefas.Count - 1].IdTarefa + 1).ToString();

                }
                else
                {
                    textBox1.Text = "1";
                }

            }
            else
            {
                MessageBox.Show("Não é possível inserir Tarefas sem haver Projetos ou Utilizadores inseridos");
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                textBox6.Enabled = false;
                textBox7.Enabled = false;
                domainUpDown1.Enabled = false;
                domainUpDown2.Enabled = false;
                button1.Enabled = false;
                label1.Enabled = false;
                label2.Enabled = false;
                label3.Enabled = false;
                label4.Enabled = false;
                label6.Enabled = false;
                label7.Enabled = false;
                label8.Enabled = false;
            }
        }
    }
}
