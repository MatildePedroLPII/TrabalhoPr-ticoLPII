﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class Ficheiro
    {
        //out List<ClassUtilizadores> utilizadores, out List<ClassProjetos> projetos, out List<ClassTarefas> tarefas, out List<ClassSprints> sprints, out List<ClassBugs> bugs
        public static List<ClassUtilizadores> utilizadores = new List<ClassUtilizadores>();
        public static List<ClassProjetos> projetos = new List<ClassProjetos>();
        public static List<ClassTarefas> tarefas = new List<ClassTarefas>();
        public static List<ClassSprints> sprints = new List<ClassSprints>();
        public static List<ClassBugs> bugs = new List<ClassBugs>();
        

        /// <summary>
        /// Método que faz a leitura de todos os dados dos ficheiros txt e guarda-os nos arrays pretendidos
        /// </summary>
        /// <returns>retorna todos os dados existentes para o programa principal</returns>
        public static void LeituraDados()
        {
            //Inicializar valores
            

            //Array que guarda todos os dados existentes nos ficheiros
            string[] utilizadoresString = File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + "utilizadores.txt");
            string[] projetosString = File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + "projetos.txt");
            string[] tarefasString = File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + "tarefas.txt");
            string[] sprintsString = File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + "sprints.txt");
            string[] bugsString = File.ReadAllLines(AppDomain.CurrentDomain.BaseDirectory + "bugs.txt");

            //Atribuição dos valores às listas
            if (utilizadoresString != null)
            {
                utilizadores = ConvertToUtilizador(utilizadoresString);
            }

            if (projetosString != null)
            {
                projetos = ConvertToProjeto(projetosString);
            }

            if (tarefasString != null)
            {
                tarefas = ConvertToTarefa(tarefasString);
            }

            if (sprintsString != null)
            {
                sprints = ConvertToSprint(sprintsString);
            }

            if (bugsString != null)
            {
                bugs = ConvertToBug(bugsString);
            }


        }

        #region Conversão
        /// <summary>
        /// Método que converte um array de strings para uma lista de utilizadores
        /// </summary>
        /// <param name="utilizadoresString">array de strings</param>
        /// <returns>lista de utilizadores</returns>
        private static List<ClassUtilizadores> ConvertToUtilizador(string[] utilizadoresString)
        {
            for (int i = 0; i < utilizadoresString.Length; i=i+3)
            {
                ClassUtilizadores utilizador = new ClassUtilizadores(int.Parse(utilizadoresString[i]),utilizadoresString[i+1], utilizadoresString[i+2]);

                utilizadores.Add(utilizador);

            }

            return utilizadores;
        }

        /// <summary>
        /// Método que converte um array de strings para uma lista de projetos
        /// </summary>
        /// <param name="projetosString">array de strings</param>
        /// <returns>lista de projetos</returns>
        private static List<ClassProjetos> ConvertToProjeto(string[] projetosString)
        {
            for (int i = 0; i < projetosString.Length; i = i + 3)
            {
                ClassProjetos projeto = new ClassProjetos(int.Parse(projetosString[i]), projetosString[i + 1], projetosString[i + 2]);

                projetos.Add(projeto);

            }

            return projetos;
        }

        /// <summary>
        /// Método que converte um array de strings para uma lista de tarefas
        /// </summary>
        /// <param name="tarefasString">array de tarefas</param>
        /// <returns>lista de tarefas</returns>
        private static List<ClassTarefas> ConvertToTarefa(string[] tarefasString)
        {
            for (int i = 0; i < tarefasString.Length; i = i + 7)
            {
                ClassTarefas tarefa = new ClassTarefas(int.Parse(tarefasString[i]), int.Parse(tarefasString[i + 1]), int.Parse(tarefasString[i + 2]), tarefasString[i + 3], tarefasString[i + 4], tarefasString[i + 5], tarefasString[i + 6]);

                tarefas.Add(tarefa);

            }

            return tarefas;
        }

        /// <summary>
        /// Método que converte um array de strings para uma lista de sprints
        /// </summary>
        /// <param name="sprintsString">array de strings</param>
        /// <returns>lista de sprints</returns>
        private static List<ClassSprints> ConvertToSprint(string[] sprintsString)
        {
            for (int i = 0; i < sprintsString.Length; i = i + 5)
            {
                ClassSprints sprint = new ClassSprints(int.Parse(sprintsString[i]), int.Parse(sprintsString[i + 1]), sprintsString[i + 2], sprintsString[i + 3], sprintsString[i + 4]);

                sprints.Add(sprint);

            }

            return sprints;
        }

        /// <summary>
        /// Método que converte um array de strings para uma lista de bugs
        /// </summary>
        /// <param name="bugsString">array de strings</param>
        /// <returns>lista de bugs</returns>
        private static List<ClassBugs> ConvertToBug(string[] bugsString)
        {

            for (int i = 0; i < bugsString.Length; i = i + 3)
            {
                ClassBugs bug = new ClassBugs(int.Parse(bugsString[i]), int.Parse(bugsString[i + 1]), bugsString[i + 2], bugsString[i + 3], bugsString[i + 4]);

                bugs.Add(bug);

            }

            return bugs;
        }

#endregion


        #region Guardar
        /// <summary>
        /// Método que escreve/guarda os utilizadores num ficheiro
        /// </summary>
        /// <param name="utilizadores">lista que contem a informação de todos os utilizadores previamente introduzidos</param>
        public static void GuardarFicheiroUtilizadores()
        {
            //Escrever no ficheiro
            using (StreamWriter ficheiro = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "utilizadores.txt"))
            {
                //Ciclo que permite a escrita dos dados no ficheiro 'utilizadores.txt'
                foreach (var utilizador in utilizadores)
                {
                    ficheiro.WriteLine(utilizador.IdUtilizador);
                    ficheiro.WriteLine(utilizador.Nome);
                    ficheiro.WriteLine(utilizador.Email);
                }
            }
        }

        /// <summary>
        /// Método que escreve/guarda os projetos num ficheiro
        /// </summary>
        /// <param name="projetos">lista que contem a informação de todos os projetos previamente introduzidos</param>
        public static void GuardarFicheiroProjetos()
        {
            //Escrever no ficheiro
            using (StreamWriter ficheiro = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "projetos.txt"))
            {
                //Ciclo que permite a escrita dos dados no ficheiro 'projetos.txt'
                foreach (var projeto in projetos)
                {
                    ficheiro.WriteLine(projeto.IdProjeto);
                    ficheiro.WriteLine(projeto.Nome);
                    ficheiro.WriteLine(projeto.DataInicio);
                }
            }
        }

        /// <summary>
        /// Método que escreve/guarda as tarefas num ficheiro
        /// </summary>
        /// <param name="tarefas">lista que contem a informação de todos as tarefas previamente introduzidas</param>
        public static void GuardarFicheiroTarefas()
        {
            //Escrever no ficheiro
            using (StreamWriter ficheiro = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "tarefas.txt"))
            {
                //Ciclo que permite a escrita dos dados no ficheiro 'tarefas.txt'
                foreach (var tarefa in tarefas)
                {
                    ficheiro.WriteLine(tarefa.IdTarefa);
                    ficheiro.WriteLine(tarefa.IdProjeto);
                    ficheiro.WriteLine(tarefa.IdUtilizador);
                    ficheiro.WriteLine(tarefa.Agenda);
                    ficheiro.WriteLine(tarefa.Titulo);
                    ficheiro.WriteLine(tarefa.Descricao);
                    ficheiro.WriteLine(tarefa.Estado);
                }
            }
        }

        /// <summary>
        /// Método que escreve/guarda os sprints num ficheiro
        /// </summary>
        /// <param name="sprints">lista que contem a informação de todos os sprints previamente introduzidos</param>
        public static void GuardarFicheiroSprints()
        {
            //Escrever no ficheiro
            using (StreamWriter ficheiro = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "sprints.txt"))
            {
                //Ciclo que permite a escrita dos dados no ficheiro 'sprints.txt'
                foreach (var sprint in sprints)
                {
                    ficheiro.WriteLine(sprint.IdSprint);
                    ficheiro.WriteLine(sprint.IdProjeto);
                    ficheiro.WriteLine(sprint.Agenda);
                    ficheiro.WriteLine(sprint.Descricao);
                    ficheiro.WriteLine(sprint.Estado);
                }
                
            }
        }

        /// <summary>
        /// Método que escreve/guarda os bugs num ficheiro
        /// </summary>
        /// <param name="bugs">lista que contem a informação de todos os bugs previamente introduzidos</param>
        public static void GuardarFicheiroBugs()
        {
            //Escrever no ficheiro
            using (StreamWriter ficheiro = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "bugs.txt"))
            {
                //Ciclo que permite a escrita dos dados no ficheiro 'bugs.txt'
                foreach (var bug in bugs)
                {
                    ficheiro.WriteLine(bug.IdBug);
                    ficheiro.WriteLine(bug.IdProjeto);
                    ficheiro.WriteLine(bug.Titulo);
                    ficheiro.WriteLine(bug.Descricao);
                    ficheiro.WriteLine(bug.Estado);
                }
                
            }
        }
        #endregion


        #region Inserir
        public static void InserirUtilizadores(ClassUtilizadores utilizador)
        {
            utilizadores.Add(utilizador);
        }

        public static List<ClassProjetos> InserirProjetos(ClassProjetos projeto)
        {
            projetos.Add(projeto);

            return projetos;
        }

        public static List<ClassTarefas> InserirTarefas(ClassTarefas tarefa)
        {
            tarefas.Add(tarefa);

            return tarefas;
        }

        public static List<ClassSprints> InserirSprints(ClassSprints sprint)
        {
            sprints.Add(sprint);

            return sprints;
        }

        public static List<ClassBugs> InserirBugs(ClassBugs bug)
        {
            bugs.Add(bug);

            return bugs;
        }
        #endregion


        #region Editar
        public static List<ClassUtilizadores> EditarUtilizadores(ClassUtilizadores utilizador)
        {
            for (int i = 0; i < utilizadores.Count; i++)
            {
                if (utilizador.IdUtilizador == utilizadores[i].IdUtilizador)
                {
                    utilizadores[i] = utilizador;
                }
            }

            return utilizadores;
        }

        public static List<ClassProjetos> EditarProjetos(ClassProjetos projeto)
        {
            for (int i = 0; i < projetos.Count; i++)
            {
                if (projeto.IdProjeto == projetos[i].IdProjeto)
                {
                    projetos[i] = projeto;
                }
            }

            return projetos;
        }

        public static List<ClassTarefas> EditarTarefas(ClassTarefas tarefa)
        {
            for (int i = 0; i < tarefas.Count; i++)
            {
                if (tarefa.IdTarefa == tarefas[i].IdTarefa)
                {
                    tarefas[i] = tarefa;
                }
            }

            return tarefas;
        }

        public static List<ClassSprints> EditarSprints(ClassSprints sprint)
        {
            for (int i = 0; i < sprints.Count; i++)
            {
                if (sprint.IdSprint == sprints[i].IdSprint)
                {
                    sprints[i] = sprint;
                }
            }

            return sprints;
        }

        public static List<ClassBugs> EditarBugs(ClassBugs bug)
        {
            for (int i = 0; i < bugs.Count; i++)
            {
                if (bug.IdBug == bugs[i].IdBug)
                {
                    bugs[i] = bug;
                }
            }

            return bugs;
        }
        #endregion


        #region Eliminar
        public static List<ClassUtilizadores> EliminarUtilizadores(ClassUtilizadores utilizador)
        {
            utilizadores.RemoveAt(utilizador.IdUtilizador-1);

            return utilizadores;
        }

        public static List<ClassProjetos> EliminarProjetos(ClassProjetos projeto)
        {
            projetos.RemoveAt(projeto.IdProjeto-1);

            return projetos;
        }

        public static List<ClassTarefas> EliminarTarefas(ClassTarefas tarefa)
        {
            tarefas.Remove(tarefa);

            return tarefas;
        }

        public static List<ClassSprints> EliminarSprints(ClassSprints sprint)
        {
            sprints.Remove(sprint);

            return sprints;
        }

        public static List<ClassBugs> EliminarBugs(ClassBugs bug)
        {
            bugs.Remove(bug);

            return bugs;
        }
        #endregion

    }
}
