﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class ClassSprints
    {

        #region ATRIBUTOS
        int idSprint;
        int idProjeto;
        string agenda;
        string descricao;
        string estado;
        #endregion

        #region CONTRUTORES
        /// <summary>
        /// Construtor por omissão
        /// </summary>
        public ClassSprints()
        {
            idSprint = 0;
            idProjeto = 0;
            agenda = null;
            descricao = null;
            estado = null;
        }

        /// <summary>
        /// Construtor definido através dos valores dos argumentos
        /// </summary>
        /// <param name="idSprint">id Sprint</param>
        /// <param name="idProjeto">id Projeto</param>
        /// <param name="agenda">agenda do sprint</param>
        /// <param name="descricao">descricao do sprint</param>
        /// <param name="estado">estado do sprint</param>
        public ClassSprints(int idSprint, int idProjeto, string agenda, string descricao, string estado)
        {
            this.idSprint = idSprint;
            this.idProjeto = idProjeto;
            this.agenda = agenda;
            this.descricao = descricao;
            this.estado = estado;
        }
        #endregion

        #region PROPRIEDADES

        /// <summary>
        /// Devolve/Define o id do Sprint
        /// </summary>
        public int IdSprint
        {
            get { return idSprint; }
            set { idSprint = value; }
        }

        /// <summary>
        /// Devolve/Define o id do Projeto
        /// </summary>
        public int IdProjeto
        {
            get { return idProjeto; }
            set { idProjeto = value; }
        }

        /// <summary>
        /// Devolve/Define o agenda do Sprint
        /// </summary>
        public string Agenda
        {
            get { return agenda; }
            set { agenda = value; }
        }

        /// <summary>
        /// Devolve/Define o descricao do Sprint
        /// </summary>
        public string Descricao
        {
            get { return descricao; }
            set { descricao = value; }
        }

        /// <summary>
        /// Devolve/Define o estado do Sprint
        /// </summary>
        public string Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        #endregion


    }
}
