﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class ClassTarefas
    {
        #region ATRIBUTOS
        int idTarefa;
        int idProjeto;
        int idUtilizador;
        string agenda;
        string titulo;
        string descricao;
        string estado;
        #endregion

        #region CONTRUTORES
        /// <summary>
        /// Construtor por omissão
        /// </summary>
        public ClassTarefas()
        {
            idTarefa = 0;
            idProjeto = 0;
            idUtilizador = 0;
            agenda = null;
            titulo = null;
            descricao = null;
            estado = null;
        }

        /// <summary>
        /// Construtor definido através dos valores dos argumentos
        /// </summary>
        /// <param name="idTarefa">id Tarefa</param>
        /// <param name="idProjeto">id Projeto</param>
        /// <param name="idUtilizador">id Utilizador</param>
        /// <param name="agenda">data para a qual a tarefa necessita de estar pronta</param>
        /// <param name="titulo">titulo da tarefa</param>
        /// <param name="descricao">descricao do que é necessário realizar na tarefa</param>
        /// <param name="estado">estado da tarefa</param>
        public ClassTarefas(int idTarefa, int idProjeto, int idUtilizador, string agenda, string titulo, string descricao, string estado)
        {
            this.idTarefa = idTarefa;
            this.idProjeto = idProjeto;
            this.idUtilizador = idUtilizador;
            this.agenda = agenda;
            this.titulo = titulo;
            this.descricao = descricao;
            this.estado = estado;
        }
        #endregion

        #region PROPRIEDADES

        /// <summary>
        /// Devolve/Define o id da Tarefa
        /// </summary>
        public int IdTarefa
        {
            get { return idTarefa; }
            set { idTarefa = value; }
        }

        /// <summary>
        /// Devolve/Define o id do projeto
        /// </summary>
        public int IdProjeto
        {
            get { return idProjeto; }
            set { idProjeto = value; }
        }

        /// <summary>
        /// Devolve/Define o id do utilizador
        /// </summary>
        public int IdUtilizador
        {
            get { return idUtilizador; }
            set { idUtilizador = value; }
        }

        /// <summary>
        /// Devolve/Define a agenda
        /// </summary>
        public string Agenda
        {
            get { return agenda; }
            set { agenda = value; }
        }

        /// <summary>
        /// Devolve/Define o titulo da tarefa
        /// </summary>
        public string Titulo
        {
            get { return titulo; }
            set { titulo = value; }
        }

        /// <summary>
        /// Devolve/Define a descricao da tarefa
        /// </summary>
        public string Descricao
        {
            get { return descricao; }
            set { descricao = value; }
        }

        /// <summary>
        /// Devolve/Define o estado da tarefa
        /// </summary>
        public string Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        #endregion

    }
}
