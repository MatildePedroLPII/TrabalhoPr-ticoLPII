﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class ClassBugs
    {

        #region ATRIBUTOS
        int idBug;
        int idProjeto;
        string titulo;
        string descricao;
        string estado;
        #endregion

        #region CONTRUTORES
        /// <summary>
        /// Construtor por omissão
        /// </summary>
        public ClassBugs()
        {
            idBug = 0;
            idProjeto = 0;
            titulo = null;
            descricao = null;
            estado = null;
        }

        /// <summary>
        /// Construtor definido através dos valores dos argumentos
        /// </summary>
        /// <param name="idBug">id Bug</param>
        /// <param name="idProjeto">id Projeto</param>
        /// <param name="titulo">titulo do bug</param>
        /// <param name="descricao">descricao do bug</param>
        /// <param name="estado">estado do bug</param>
        public ClassBugs(int idBug, int idProjeto, string titulo, string descricao, string estado)
        {
            this.idBug = idBug;
            this.idProjeto = idProjeto;
            this.titulo = titulo;
            this.descricao = descricao;
            this.estado = estado;
        }
        #endregion

        #region PROPRIEDADES

        /// <summary>
        /// Devolve/Define o id do Bug
        /// </summary>
        public int IdBug
        {
            get { return idBug; }
            set { idBug = value; }
        }
        
        /// <summary>
        /// Devolve/Define o id do Projeto
        /// </summary>
        public int IdProjeto
        {
            get { return idProjeto; }
            set { idProjeto = value; }
        }

        /// <summary>
        /// Devolve/Define o titulo da bug
        /// </summary>
        public string Titulo
        {
            get { return titulo; }
            set { titulo = value; }
        }

        /// <summary>
        /// Devolve/Define o descricao do bug
        /// </summary>
        public string Descricao
        {
            get { return descricao; }
            set { descricao = value; }
        }

        /// <summary>
        /// Devolve/Define o estado do bug
        /// </summary>
        public string Estado
        {
            get { return estado; }
            set { estado = value; }
        }

        #endregion

    }
}
