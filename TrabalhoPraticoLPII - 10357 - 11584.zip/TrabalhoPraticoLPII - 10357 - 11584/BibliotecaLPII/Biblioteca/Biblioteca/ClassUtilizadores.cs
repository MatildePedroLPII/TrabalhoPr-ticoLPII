﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Biblioteca
{
    public class ClassUtilizadores
    {

        #region ATRIBUTOS
        int idUtilizador;
        string nome;
        string email;
        #endregion

        #region CONTRUTORES
        /// <summary>
        /// Construtor por omissão
        /// </summary>
        public ClassUtilizadores()
        {
            idUtilizador = 0;
            nome = null;
            email = null;
        }

        /// <summary>
        /// Construtor definido através dos valores dos argumentos
        /// </summary>
        /// <param name="id">id Utilizador</param>
        /// <param name="nomeUtilizador">nome do Utilizador</param>
        /// <param name="emailUtilizador">email do Utilizador</param>
        public ClassUtilizadores(int id, string nomeUtilizador, string emailUtilizador)
        {
            idUtilizador = id;
            nome = nomeUtilizador;
            email = emailUtilizador;
        }
        #endregion

        #region PROPRIEDADES

        /// <summary>
        /// Devolve/Define o id do utilizador
        /// </summary>
        public int IdUtilizador
        {
            get { return idUtilizador; }
            set { idUtilizador = value; }
        }

        /// <summary>
        /// Devolve/Define o nome da pessoa
        /// </summary>
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        /// <summary>
        /// Devolve/Define o email do utilizador
        /// </summary>
        public string Email
        {
            get { return email; }
            set { email = value; }
        }


        #endregion

    }
}
