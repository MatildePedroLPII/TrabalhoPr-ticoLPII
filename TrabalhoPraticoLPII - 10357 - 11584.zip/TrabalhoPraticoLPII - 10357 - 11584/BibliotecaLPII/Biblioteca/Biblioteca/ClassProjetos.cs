﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class ClassProjetos
    {

        #region ATRIBUTOS
        int idProjeto;
        string nome;
        string dataInicio;
        #endregion

        #region CONTRUTORES
        /// <summary>
        /// Construtor por omissão
        /// </summary>
        public ClassProjetos()
        {
            idProjeto = 0;
            nome = null;
            dataInicio = null;
        }

        /// <summary>
        /// Construtor definido através dos valores dos argumentos
        /// </summary>
        /// <param name="idProjeto">id projeto</param>
        /// <param name="nome">nome do projeto</param>
        /// <param name="dataInicio">data inicio do projeto</param>
        public ClassProjetos(int idProjeto, string nome, string dataInicio)
        {
            this.idProjeto = idProjeto;
            this.nome = nome;
            this.dataInicio = dataInicio;
        }
        #endregion

        #region PROPRIEDADES

        /// <summary>
        /// Devolve/Define o id do Projeto
        /// </summary>
        public int IdProjeto
        {
            get { return idProjeto; }
            set { idProjeto = value; }
        }

        /// <summary>
        /// Devolve/Define o nome do Projeto
        /// </summary>
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        /// <summary>
        /// Devolve/Define o data de inicio do projeto
        /// </summary>
        public string DataInicio
        {
            get { return dataInicio; }
            set { dataInicio = value; }
        }


        #endregion


    }
}
